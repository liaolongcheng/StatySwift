![image](https://github.com/xhzengAIB/LearnEnglish/raw/master/Screenshots/XHNews.gif)

XHNewsParsing
=============

XHNewsParsing is sina news client, use swift. 

1、use NSOperationQueue and NSURLConnection load net work data.                                  
2、use UITableView show news data.                                


